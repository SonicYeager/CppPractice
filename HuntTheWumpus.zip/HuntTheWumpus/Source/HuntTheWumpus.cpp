#include "HuntTheWumpus.h"
#include "EndProgramMsg.h"
#include "UserInputMsg.h"
#include "GameLoopImpl.h"

namespace HtW
{
	HuntTheWumpus::HuntTheWumpus(RandomGenerator* pg)
		: m_pRandom(pg)
	{
		InitMessageIDs();
		RegisterMessageHandler();
	}

	void HuntTheWumpus::Run()
	{
		//TODO Hier eine Nachricht einfügen die die Cave erstellt bevor es losgeht
		m_Loop.Run();
	}

	void HuntTheWumpus::InitMessageIDs()
	{
		EndProgramMsg::ID = 0;
		UserInputMsg::ID = 1;
		//TODO: Für jede weitere Message die ID hier aufsteigend zuweisen
	}

	void HuntTheWumpus::RegisterMessageHandler()
	{
		m_Loop.SetHandlerCount(2);
		m_Loop.RegisterHandler(EndProgramMsg::ID, new EndProgramMsgHandler(&m_Loop));
		m_Loop.RegisterHandler(UserInputMsg::ID, new UserInputMsgHandler(&m_Loop));
		//TODO: Für jede weitere Message den handler hier anbinden und den handler count erhöhen
	}

} // namespace HtW
