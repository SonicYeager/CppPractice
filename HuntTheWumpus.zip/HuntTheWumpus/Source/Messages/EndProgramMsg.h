#pragma once
#include "Message.h"
#include "GameLoop.h"

namespace HtW
{
	class EndProgramMsg : public Message
	{
	public:
		int GetID() const override;

		//Will set in App::InitMessageHandling to guaranty unique IDs
		static int ID;
	};

	class EndProgramMsgHandler : public MessageHandler
	{
	public:
		explicit EndProgramMsgHandler(GameLoop*);

		void Process(const Message&) override;

	private:
		GameLoop* m_pLoop;
	};
} // namespace HtW
