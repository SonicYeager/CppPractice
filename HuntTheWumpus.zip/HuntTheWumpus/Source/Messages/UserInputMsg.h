#pragma once
#include "Message.h"
#include "GameLoop.h"

namespace HtW
{
	class UserInputMsg : public Message
	{
	public:
		int GetID() const override;

		static int ID;
	};

	class UserInputMsgHandler : public MessageHandler
	{
	public:
		UserInputMsgHandler(GameLoop*);

		void Process(const Message&) override;

	private:
		GameLoop* m_pLoop;
	};
} // namespace HtW
