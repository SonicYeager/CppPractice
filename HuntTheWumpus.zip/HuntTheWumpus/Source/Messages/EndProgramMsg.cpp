#include "EndProgramMsg.h"
#include "GameLoopImpl.h"
#include <iostream>

namespace HtW
{
	int EndProgramMsg::ID = -1;

	int EndProgramMsg::GetID() const
	{
		return EndProgramMsg::ID;
	}

	EndProgramMsgHandler::EndProgramMsgHandler(GameLoop* pg)
		: m_pLoop(pg)
	{}

	void EndProgramMsgHandler::Process(const Message&)
	{
		dynamic_cast<GameLoopImpl*>(m_pLoop)->Stop();
		std::cin.get();
	}

} // namespace HtW
