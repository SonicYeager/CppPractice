#include "UserInputMsg.h"
#include <iostream>
#include "EndProgramMsg.h"

namespace HtW
{
	int UserInputMsg::ID = -1;

	int UserInputMsg::GetID() const
	{
		return UserInputMsg::ID;
	}

	UserInputMsgHandler::UserInputMsgHandler(GameLoop* pl)
		: m_pLoop(pl)
	{}

	void UserInputMsgHandler::Process(const Message&)
	{
		std::cout << "\n(A)bbrechen?";
		char buffer[4] = {};
		std::cin.getline(buffer, 4);
		char choice = buffer[0];
		if(choice == 'A' or choice == 'a')
		{
			std::cout << "Game Over!";
			m_pLoop->Push(new EndProgramMsg);
		}
	}

} // namespace HtW
