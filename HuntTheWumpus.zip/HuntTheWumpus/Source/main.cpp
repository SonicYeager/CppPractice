#include "HuntTheWumpus.h"

int main()
{
	//TODO instantiate your random number generator here and replace nullptr
	HtW::HuntTheWumpus app(nullptr);
	app.Run();
	return 0;
}
