# GameOfLife
A little training task to practice JavaScript.
And a private project just to do something instead of just thinking about how nice coding is. :D

## How to use ? 
- for now the object instanciation is hardcoded and the parameters can be changed there.
- all main methods can be found in the code inside of app.js

## What needs to be done ?
- creating a form for userinput
- make it possible to change the cell via cursor and drawing in them before and while the evolution is stopt
