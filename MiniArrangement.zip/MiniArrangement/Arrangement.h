#pragma once
#include "Track.h"

class Arrangment : public IVisitable
{
public:
	Arrangment();
	~Arrangment();

	void Visit(IOperations*) override;

	void AddClip(int tracknumber, ClipPtr);
	std::chrono::milliseconds TotalLength() const;

	ClipPtr FindByNumber(int) const;
	ClipPtrs FindAllVideos() const;
	ClipPtrs FindAllTitle() const;

	Track* tracks;
	ClipPtrs clips;
};
