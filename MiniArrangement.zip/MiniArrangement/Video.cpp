#include "Video.h"

Video::Video(std::chrono::milliseconds start, std::chrono::milliseconds length, const wchar_t* fp)
	: Clip{start, length}
	, filePath(new wchar_t[std::wcslen(fp)])
{
	std::wcscpy(filePath, fp);
}

Video::~Video()
{
	delete[] filePath;
}

void Video::Visit(IOperations*)
{
	//Visitor
}
