#pragma once
#include "Clip.h"

using ClipPtr = Clip*;
using ClipPtrs = Clip**;

class Track : public IVisitable
{
public:
	Track();
	~Track();

	void Visit(IOperations*) override;

	void AddClip(ClipPtr);
	ClipPtr FindByNumber(int) const;

	ClipPtrs clips;
};
