#include "Track.h"

Track::Track()
	: clips(new ClipPtr[1])
{}

Track::~Track()
{
	delete[] clips;
}

void Track::AddClip(ClipPtr clip)
{
	//Add clip to clips
	//Sort clips array by start time, use std::sort
	//Adapt start of overlapping clips
}

ClipPtr Track::FindByNumber(int) const
{
	//Find
	return nullptr;
}

void Track::Visit(IOperations*)
{
	//Visitor
}
