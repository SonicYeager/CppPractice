#include "Arrangement.h"
#include "Video.h"
#include "Audio.h"
#include "Title.h"

int main()
{
	Arrangment arrangment;
	arrangment.AddClip(1, new Audio(100ms, 2000ms, L"audio/Trumpets.mp3", 100));
	arrangment.AddClip(1, new Video(1000ms, 500ms, L"video/Alice.m2ts"));
	arrangment.AddClip(1, new Title(2500ms, 200ms, "Hello World!", 12));
	arrangment.AddClip(2, new Title(500ms, 500ms, "Small Subtitle...", 10));
	arrangment.AddClip(2, new Audio(1000ms, 500ms, L"video/Alice.wav", 80));
	arrangment.AddClip(3, new Title(2600ms, 500ms, "Smaller Subtitle...", 8));
	return 0;
}
