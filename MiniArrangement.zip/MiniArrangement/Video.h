#pragma once
#include "Clip.h"

class Video : public Clip
{
public:
	Video(std::chrono::milliseconds start, std::chrono::milliseconds length, const wchar_t* filePath);
	~Video() override;

	void Visit(IOperations*) override;

	wchar_t* filePath;
};
