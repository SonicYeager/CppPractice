#include "Audio.h"

Audio::Audio(std::chrono::milliseconds start, std::chrono::milliseconds length, const wchar_t* fp, int vol)
	: Clip{start, length}
	, filePath(new wchar_t[std::wcslen(fp)])
	, volume(vol)
{
	std::wcscpy(filePath, fp);
}

Audio::~Audio()
{
	delete[] filePath;
}

void Audio::Visit(IOperations*)
{
	//Visitor
}
