#pragma once
#include "Clip.h"

class Title : public Clip
{
public:
	Title(std::chrono::milliseconds start, std::chrono::milliseconds length, const char* txt, int size);
	~Title() override;
	void Visit(IOperations*) override;

	char* text;
	int pointSize;
};
