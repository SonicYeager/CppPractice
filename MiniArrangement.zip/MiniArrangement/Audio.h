#pragma once
#include "Clip.h"

class Audio : public Clip
{
public:
	Audio(std::chrono::milliseconds start, std::chrono::milliseconds length, const wchar_t* filePath, int volume);
	~Audio() override;

	void Visit(IOperations*) override;

	wchar_t* filePath;
	int volume;
};
