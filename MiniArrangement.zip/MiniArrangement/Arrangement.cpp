#include "Arrangement.h"

Arrangment::Arrangment()
	: tracks{}
	, clips(new ClipPtr[1])
{}

Arrangment::~Arrangment()
{
	delete[] tracks;
	delete[] clips;
}

void Arrangment::Visit(IOperations*)
{
	//Visitor
}

void Arrangment::AddClip(int tracknumber, ClipPtr clip)
{
}

std::chrono::milliseconds Arrangment::TotalLength() const
{
	return {};
}

ClipPtr Arrangment::FindByNumber(int) const
{
	//Find
	ClipPtr result = nullptr;
	return result;
}

ClipPtrs Arrangment::FindAllVideos() const
{
	//Find
	auto result = new ClipPtr[1];
	return result;
}

ClipPtrs Arrangment::FindAllTitle() const
{
	//Find
	auto result = new ClipPtr[1];
	return result;
}
