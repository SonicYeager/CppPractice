#pragma once

class Video;
class Audio;
class Title;
class Track;
class Arrangment;
class IOperations;

class IVisitable
{
public:
	virtual void Visit(IOperations*) = 0;
	virtual ~IVisitable() = default;
};

using VideoPtr = Video*;
using AudioPtr = Audio*;
using TitlePtr = Title*;

class IOperations
{
public:
	inline void operator()(IVisitable* performOn)
	{
		performOn->Visit(this);
	}
	virtual void PerformOn(const VideoPtr&) = 0;
	virtual void PerformOn(const AudioPtr&) = 0;
	virtual void PerformOn(const TitlePtr&) = 0;
	virtual void PerformOn(Track*) = 0;
	virtual void PerformOn(Arrangment*) = 0;
	~IOperations() = default;
};
