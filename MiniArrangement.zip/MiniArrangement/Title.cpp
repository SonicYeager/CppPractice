#include "Title.h"
#include <cstring>

Title::Title(std::chrono::milliseconds start, std::chrono::milliseconds length, const char* txt, int size)
	: Clip{start, length}
	, text(new char[std::strlen(txt)])
	, pointSize(size)
{
	std::strcpy(text, txt);
}

Title::~Title()
{
	delete[] text;
}

void Title::Visit(IOperations*)
{
	//Visitor
}
