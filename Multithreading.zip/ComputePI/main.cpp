#include "Tools.h"

// Algorithmus:
// Zur Bestimmung von PI werden zuf�llig Koordinaten in einem 2x2 Rechteck (Mittelpunkt (0,0), Seitel�nge 2) bestimmt
// Anschlie�end wird gepr�ft, ob die Koordinate innerhalb des Kreises (Mittelpunkt (0,0) und Radius von 1.0) ist
// Ist das der Fall ist es ein Treffer
// Die Fl�che des Einheitskreise betr�gt Pi*r^2 = Pi*1^2 = Pi
// Die Fl�che des Rechtecks betr�gt a*b = 2*2 = 4
// Durch das Verh�ltnis Treffer/W�rfe = Pi / 4, l�sst sich Pi bestimmen, Pi = 4 * Treffer/W�rfe
double ComputePISequential(int numSteps)
{
	// Anzahl von Treffern die im Kreis landen
	int numHitsInCircle = 0;
	for(int k = 0; k < numSteps; ++k)
	{
		// Zuf�llige Koordinate in dem Rechteck [-1,1]x[-1,1] bestimmen
		double x_coord = 2.0 * Random() - 1.0;
		double y_coord = 2.0 * Random() - 1.0;
		// Liegt die Koordinate im Kreis?
		if(x_coord*x_coord + y_coord*y_coord <= 1.0)
			++numHitsInCircle;
	}
	// Pi berechnen
	return 4.0 * static_cast<double>(numHitsInCircle) / numSteps;
}

struct ThreadParam
{
	int start;
	int end;
};

struct ThreadParamWithHits : ThreadParam
{
	int localNumHitsInCircle;
};

int main()
{
	int numSteps = 1000000;
	int numThreads = 1;
	Measurment measure(numSteps);
	measure.Start("Sequ");
	double pi = ComputePISequential(numSteps);
	measure.Stop(pi, numThreads);

	// Deine L�sung folgt hier

	return 0;
}
