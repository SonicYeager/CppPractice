#include "Tools.h"
#include <iostream>
//TODO include here

double Random()
{
	//TODO Generate random uniform number
	return 0.0;
}

Measurment::Measurment(int numSteps)
	: out("PerfMeasurements.txt", std::ios_base::app)
{
	out << "Start measurement with " << numSteps << " steps\n";
}

void Measurment::Start(std::string_view testName)
{
	name = testName;
	//TODO start = ;
}

void Measurment::Stop(double pi, int numThreads)
{
	//TODO auto duration = ;
	out << name << ": computes PI=" << pi << " with " << numThreads << " Thread(s) in "
		//TODO << duration...
		<< " ms\n";
}
