#pragma once
#include <string>
#include <fstream>
//TODO include here

// Returns random number between [0,1]
double Random();

class Measurment
{
public:
	explicit Measurment(int numSteps);
	void Start(std::string_view testName);
	void Stop(double pi, int numThreads);
	
private:
	std::ofstream out;
	std::string name;
	//TODO ... start;
};