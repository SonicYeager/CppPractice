#include "ComputePrimeNumbers.h"
#include <thread>
#include <algorithm>

PrimeNumbers ComputePrimeNumbers::ComputePrimes(Range range)
{
	PrimeNumbers result;
	int last = range.end;
	int candidate = std::max(2, range.begin);
	while(candidate < last)
	{
		bool isPrime = true;
		for(int trialDivisor = 2; trialDivisor * trialDivisor <= candidate; ++trialDivisor)
		{
			if(candidate % trialDivisor == 0)
			{
				isPrime = false;
				break;
			}
		}
		if(isPrime)
		{
			result.push_back(candidate);
			//Slowdown computation ;)
			std::this_thread::sleep_for(std::chrono::milliseconds(250));
		}
		candidate++;
	}
	return result;
}
