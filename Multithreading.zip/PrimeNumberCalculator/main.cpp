#include "Ui.h"
#include "ComputePrimeNumbers.h"

void StartNewComputation(Range range, Ui& ui)
{
	ComputePrimeNumbers logic;
	auto primes  = logic.ComputePrimes(range);
	ui.ShowResult(range, primes);
}

int main()
{
	Ui ui;
	ui.onRange = std::bind(StartNewComputation, std::placeholders::_1, std::ref(ui));

	ui.Run();
	return 0;
}
