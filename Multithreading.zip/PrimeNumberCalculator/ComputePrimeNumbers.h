#pragma once
#include "Contracts.h"

class ComputePrimeNumbers
{
public:
	PrimeNumbers ComputePrimes(Range);
};
