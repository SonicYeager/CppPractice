#include "Crypto.h"
#include "Datei.h"
#include "Puffer.h"

ErrorCode ReadFileContent(const char* filename, char*& buffer, size_t& size);

ErrorCode Crypto::Run(int argc, const char* argv[])
{
	Algorithm algo{};
	int shiftCount = 0;
	Puffer sourceFilename = Puffer(nullptr);
	ErrorCode err = Parse(argc, argv, algo, shiftCount, sourceFilename.SetChar());
	if(err == SUCCESS)
	{
		err = ValidateInput(algo, shiftCount, sourceFilename.GetChar());
		if(err != SUCCESS)
		{
			return err;
		}

		Puffer buffer = Puffer(nullptr);
		size_t size = 0;
		err = ReadFileContent(sourceFilename.GetChar(), buffer.SetChar(), size);
		if(err == SUCCESS)
		{
			Datei dest = Datei("result.txt", "wb");
			if(dest.GetFile() != nullptr)
			{
				err = Process(algo, buffer.GetChar(), size, shiftCount);
				if(err == SUCCESS)
				{
					size_t written = fwrite(buffer.GetChar(), sizeof(char), size, dest.GetFile());
					if(written != size)
					{
						err = WRITE_FILE_FAILED;
						PrintError(err, "Write result.txt failed");
						return err;
					}
				}
				else
					PrintError(err, "Crypto failed");
				//fclose(dest);
			}
			else
			{
				err = OPEN_FILE_FAILED;
				PrintError(err, "result.txt");
			}
		}
		else
			PrintError(err, sourceFilename.GetChar());
	}
	else
		PrintError(err, "Parse failed");
	return err;
}

ErrorCode Crypto::Parse(int argc, const char* argv[], Algorithm& algo, int& shiftCount, char*& pFilename)
{
	if(argc < 3)
		return NO_INPUT;

	ErrorCode err = ParseAlgorithm(argv[0], algo);
	if(err != SUCCESS)
		return err;
	err = ParseCount(argv[1], shiftCount);
	if(err != SUCCESS)
		return err;
	err = ParseFilename(argv[2], pFilename);
	return err;
}

ErrorCode Crypto::ParseAlgorithm(const char* algoString, Algorithm& result)
{
	result = static_cast<Algorithm>(std::atoi(algoString));
	return SUCCESS;
}

ErrorCode Crypto::ParseCount(const char* countString, int& result)
{
	result = std::atoi(countString);
	return SUCCESS;
}

ErrorCode Crypto::ParseFilename(const char* filename, char*& pResult)
{
	size_t len = std::strlen(filename);
	pResult = new char[len + 1]{};
	std::strcpy(pResult, filename);
	return SUCCESS;
}

ErrorCode Crypto::ValidateInput(Algorithm algo, int shiftCount, const char* filename)
{
	if(shiftCount < -25 or 25 < shiftCount)
	{
		PrintError(WRONG_PARAMETER, "Shift count only valid in range[-25, 25]");
		return WRONG_PARAMETER;
	}
	size_t len = std::strlen(filename);
	if(len == 0)
	{
		PrintError(WRONG_PARAMETER, "Empty filename");
		return WRONG_PARAMETER;
	}
	if(static_cast<int>(Algorithm::Last) < static_cast<int>(algo) or static_cast<int>(algo) < static_cast<int>(Algorithm::None))
	{
		PrintError(WRONG_PARAMETER, "Invalid algorithm");
		return WRONG_PARAMETER;
	}
	return SUCCESS;
}

ErrorCode Crypto::Process(Algorithm algo, char* pBuffer, size_t size, int shiftCount)
{
	switch(algo)
	{
	case Algorithm::CeasarEncode: return Encode(pBuffer, size, shiftCount);
	case Algorithm::CeasarDecode: return Decode(pBuffer, size, shiftCount);
	}
	return UNKNOWN_ALGORITHM;
}

ErrorCode Crypto::Encode(char* pBuffer, size_t size, int shiftCount)
{
	if(pBuffer == nullptr)
		return WRONG_PARAMETER;
	if(size == 0)
		return WRONG_PARAMETER;

	for(size_t i = 0; i < size; ++i)
	{
		if(pBuffer[i] >= 'a' and pBuffer[i] <= 'z')
		{
			char letter = pBuffer[i] + shiftCount;
			if(letter > 'z')
				letter -= 26;
			if(letter < 'a')
				letter += 26;
			pBuffer[i] = letter;
		}
		else if(pBuffer[i] >= 'A' and pBuffer[i] <= 'Z')
		{
			char letter = pBuffer[i] + shiftCount;
			if(letter > 'Z')
				letter -= 26;
			if(letter < 'A')
				letter += 26;
			pBuffer[i] = letter;
		}
	}
	return SUCCESS;
}

ErrorCode Crypto::Decode(char* pBuffer, size_t size, int shiftCount)
{
	return Encode(pBuffer, size, -shiftCount);
}

void Crypto::PrintError(ErrorCode err, const char* pMsg)
{
	std::cout << "Error: " << err << ' ' << pMsg << '\n';
}

ErrorCode ReadFileContent(const char* pFilename, char*& pResult, size_t& size)
{
	if(pFilename == nullptr)
		return WRONG_PARAMETER;

	Datei src = Datei(pFilename, "rb");
	if(src.GetFile() == nullptr)
		return OPEN_FILE_FAILED;

	fseek(src.GetFile(), 0, SEEK_END);
	size_t bytes = ftell(src.GetFile());
	rewind(src.GetFile());
	Puffer buffer = Puffer(new char[bytes], true);

	size_t read = fread(buffer.SetChar(), sizeof(char), bytes, src.GetFile());

	if(read != bytes)
	{
		return READ_FILE_FAILED;
	}
	size = bytes;
	pResult = buffer.GetChar();
	return SUCCESS;
}
