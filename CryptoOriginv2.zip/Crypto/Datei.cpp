#include "Datei.h"

FILE * Datei::GetFile()
{
	return this->mp_file;
}
