#pragma once

#ifdef NBACK_EXPORTS
#define NBACK_API __declspec(dllexport)
#else
#define NBACK_API __declspec(dllimport)
#endif

namespace $ext_safeprojectname$
{

}