---
name: Xamarin.Android - Phoneword
description: "Sample app for the article, Hello, Android (Quickstart). This version of Phoneword incorporates all of the functionality... (get started)"
page_type: sample
languages:
- csharp
products:
- xamarin
extensions:
    tags:
    - getstarted
urlFragment: phoneword
---
# Phoneword

This sample app accompanies the article,
[Hello, Android (Quickstart)](https://docs.microsoft.com/xamarin/android/get-started/hello-android/hello-android-quickstart).
This version of **Phoneword** incorporates all of the functionality
explained in this article, and it can be used as the starting point for
the article,
[Hello, Android Multiscreen (Quickstart)](https://docs.microsoft.com/xamarin/android/get-started/hello-android-multiscreen/hello-android-multiscreen-quickstart).
